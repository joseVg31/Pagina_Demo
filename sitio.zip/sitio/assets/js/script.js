const form = document.getElementById('demoForm');
  const status = document.getElementById('formStatus');
  form.addEventListener('submit', function(e){
    e.preventDefault();
    if(form.checkValidity()){
      status.textContent = '✓ Todos los campos son válidos — listo para enviarse por POST.';
      status.classList.add('ok');
    } else {
      status.textContent = '✗ Hay campos inválidos. Revisa los bordes en rojo.';
      status.classList.remove('ok');
      form.reportValidity();
    }
  });
